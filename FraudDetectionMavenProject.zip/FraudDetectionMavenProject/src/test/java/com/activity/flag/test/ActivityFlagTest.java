package com.activity.flag.test;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import com.activity.flag.dao.CustomerDao;
import com.activity.flag.model.Customer;
import com.activity.flag.model.Transaction;
import com.activity.flag.predicate.SameAccountPredicate;
import com.activity.flag.predicate.SuspiciousActivityPredicate;
import com.activity.flag.service.CustomerService;
import com.activity.flag.util.Constants;
import com.activity.flag.util.DataTransformer;
import com.activity.flag.util.FileReaderUtil;

@TestInstance(Lifecycle.PER_CLASS)
public class ActivityFlagTest {
	
	@Test
	@DisplayName("check if customer data file exists")
	public void checkCustomerFileExists() {
		URL resource = FileReaderUtil.class.getClassLoader().getResource(Constants.CUSTOMER_DATA_FILE_NAME);
		assertNotNull(resource,"File doesn't exists or has insufficient privileges");
	}
	
	@Test
	@DisplayName("check if transaction data file exists")
	public void checkTransactionFileExists() {
		URL resource = FileReaderUtil.class.getClassLoader().getResource(Constants.TRANSACTION_DATA_FILE_NAME);
		assertNotNull(resource,"File doesn't exists or has insufficient privileges");
	}
	
	
	@Test
	@DisplayName("read customer data from file")
	public void readCustomerFile() throws URISyntaxException, IOException{
		Stream<String> customerData = FileReaderUtil.readCustomerData();
		Optional<String> firstCustomer = customerData.findFirst();
		if(firstCustomer.isPresent()){
			assertEquals("10010589|Mr. S Kumar|Flat no. 501, Green View Park,Hinjewandi, Pune|9001045238", firstCustomer.get().trim());
		}
		
	}
	
	@Test
	@DisplayName("read transaction data from file")
	public void readTansactionFile() throws URISyntaxException, IOException{
		Stream<String> transactionData = FileReaderUtil.readTransactionData();
		Optional<String> firstTransaction = transactionData.findFirst();
		if(firstTransaction.isPresent()){
			assertEquals("T0175896345|10-Jan-20|10010589|80074567|100000", firstTransaction.get().trim());
		}
		
	}
	
	@Test
	@DisplayName("test customer data transformer")
	public void testTransformToCustomer(){
		String[] customerFromFile = {"10010589|Mr. S Kumar|Flat no. 501, Green View Park,Hinjewandi, Pune|9001045238"};
		Stream<String> customerStream = Arrays.stream(customerFromFile);
		List<Customer> customers = DataTransformer.transformToCustomer(customerStream);
		Customer actualCustomer = customers != null ? customers.get(0) : null;
		Customer expectedCustomer = new Customer(Long.valueOf("10010589"), "Mr. S Kumar", "Flat no. 501, Green View Park,Hinjewandi, Pune", Long.valueOf("9001045238"));
		assertEquals(expectedCustomer, actualCustomer);
	}
	
	@Test
	@DisplayName("test transaction data transformer")
	public void testTransformToTransaction(){
		String[] transactionFromFile = {"T0175896345|10-Jan-20|10010589|80074567|100000"};
		Stream<String> transactionStream = Arrays.stream(transactionFromFile);
		List<Transaction> transactions = DataTransformer.transformToTransactions(transactionStream);
		Transaction actualTransaction = transactions != null ? transactions.get(0) : null;
		Transaction expectedTransaction = new Transaction("T0175896345",LocalDate.parse("10-Jan-20", DateTimeFormatter.ofPattern(Constants.TRANSACTION_DATE_FORMAT)), Long.valueOf("10010589"),  Long.valueOf("80074567"),  Long.valueOf("100000"));
		assertEquals(expectedTransaction, actualTransaction);
	}
	
	@Test
	@DisplayName("check address equality for customer")
	public void testCustomerAddressEquality(){
		Customer customer1 = new Customer(Long.valueOf("10010589"), "Mr. S Kumar", "Flat no. 501, Green View Park,Hinjewandi, Pune", Long.valueOf("9001045238"));
		Customer customer2 = new Customer(Long.valueOf("10010589"), "Mr. S Kumar", "Flat no. 501, Green View Park,Hinjewandi, Pune", Long.valueOf("9001045238"));
		
		Customer customer3 = new Customer(Long.valueOf("10010589"), "Mr. S Kumar", "Flat no. 501, Green View Park,Hinjewandi, Pune", Long.valueOf("9001045238"));
		Customer customer4 = new Customer(Long.valueOf("10010589"), "Mr. S Kumar", "Mumbai,India", Long.valueOf("9001045238"));
		
		CustomerService customerService = new CustomerService();
		assertAll(() -> assertTrue(customerService.equateAddress(customer1, customer2)), 
				() -> assertFalse(customerService.equateAddress(customer3, customer4)));
	}
	
	@Test
	@DisplayName("check phone number equality for customer")
	public void testCustomerPhoneNumberEquality(){
		Customer customer1 = new Customer(Long.valueOf("10010589"), "Mr. S Kumar", "Flat no. 501, Green View Park,Hinjewandi, Pune", Long.valueOf("9001045238"));
		Customer customer2 = new Customer(Long.valueOf("10010589"), "Mr. S Kumar", "Flat no. 501, Green View Park,Hinjewandi, Pune", Long.valueOf("9001045238"));
		
		Customer customer3 = new Customer(Long.valueOf("10010589"), "Mr. S Kumar", "Flat no. 501, Green View Park,Hinjewandi, Pune", Long.valueOf("9001045238"));
		Customer customer4 = new Customer(Long.valueOf("10010589"), "Mr. S Kumar", "Flat no. 501, Green View Park,Hinjewandi, Pune", Long.valueOf("9001045239"));
		
		CustomerService customerService = new CustomerService();
		assertAll(() -> assertTrue(customerService.equatePhoneNumber(customer1, customer2)), 
				() -> assertFalse(customerService.equatePhoneNumber(customer3, customer4)));
	}
	
	@Test
	@DisplayName("check if Transaction is suspicious")
	public void checkIfTransactionSuspicious(){
		Transaction transaction = new Transaction("T0175896345",LocalDate.parse("10-Jan-20", DateTimeFormatter.ofPattern(Constants.TRANSACTION_DATE_FORMAT)), Long.valueOf("10010589"),  Long.valueOf("80074567"),  Long.valueOf("100000"));
		SuspiciousActivityPredicate predicate = new SameAccountPredicate();
		assertTrue(predicate.isTransactionSuspicious(transaction),"Transaction is suspicious but not identified correctly");
		
	}
	
	@Test
	@DisplayName("get customer by account number")
	public void testGetCustomerByAccountNumber(){
		CustomerDao customerDao = new CustomerDao();
		Customer expectedCustomer = new Customer(Long.valueOf("10010589"), "Mr. S Kumar", "Flat no. 501, Green View Park,Hinjewandi, Pune", Long.valueOf("9001045238"));
		assertEquals(expectedCustomer, customerDao.getCustomerByAcccNumber(Long.valueOf(10010589)));
	}
	
	

}
