package com.activity.flag.util;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class FileReaderUtil extends Constants {
	
	public static Stream<String> readCustomerData() throws URISyntaxException, IOException {
		return readData(CUSTOMER_DATA_FILE_NAME);
	}

	public static Stream<String> readTransactionData() throws URISyntaxException, IOException {
		return readData(TRANSACTION_DATA_FILE_NAME);
	}

	public static Stream<String> readData(final String filename) throws IOException, URISyntaxException {
		URL resource = FileReaderUtil.class.getClassLoader().getResource(filename);
		return Files.lines(Paths.get(resource.toURI()));
	}

}
