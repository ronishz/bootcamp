package com.activity.flag.util;

public class Constants {
	
	public static final String CUSTOMER_DATA_FILE_NAME = "CustomerData.txt";
	public static final String TRANSACTION_DATA_FILE_NAME = "TransactionData.txt";
	public static final String TRANSACTION_DATE_FORMAT = "d-MMM-yy";
	public static final String SEPERATOR_REGEX = "\\|";
	
}
