package com.activity.flag.predicate;

import com.activity.flag.model.Transaction;

public interface SuspiciousActivityPredicate {
	
	public boolean isTransactionSuspicious(final Transaction transaction);

}
