package com.activity.flag.client;

import com.activity.flag.predicate.SameAccountPredicate;
import com.activity.flag.printing.ConsolePrinter;
import com.activity.flag.service.TransactionService;

public class Client {
	public static void main(String[] args) {
		TransactionService transactionService = new TransactionService();
		
		//Predicate holds the logic to identify suspicious transactions
		transactionService.setPredicate(new SameAccountPredicate());
		
		transactionService.setOutputFormatter(new ConsolePrinter());
		
		//generates report for quarterly transactions data
		transactionService.analyzeAndGenerateReport(); 
	}
}
