package com.activity.flag.dao;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;
import java.util.stream.Stream;

import com.activity.flag.model.Transaction;
import com.activity.flag.util.DataTransformer;
import com.activity.flag.util.FileReaderUtil;

public class TransactionDao {

	public List<Transaction> getAllTransactions() {
		List<Transaction> transactions = null;
		Stream<String> transactionDataStream = null;
		try {
			transactionDataStream = FileReaderUtil.readTransactionData();
		} catch (URISyntaxException | IOException e) {
			System.err.println("Error reading file: " + e);
		}
		transactions = DataTransformer.transformToTransactions(transactionDataStream);
		return transactions;
	}

}
