package com.activity.flag.printing;

import java.time.Month;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.activity.flag.model.Transaction;

public class ConsolePrinter implements OutputFormatter {

	public void print(final Map<Month, List<Transaction>> transactions) {

		if (transactions != null && !transactions.isEmpty()) {
			Iterator<Month> iterator = transactions.keySet().iterator();
			Set<Set<Long>> suspiciousAccounts = new HashSet<>();
			while (iterator.hasNext()) {
				Month month = iterator.next();
				System.out.println("For The Month of " + month + ":");
				System.out.println("Suspicious Transactions :");
				List<Transaction> transactionForCurrMonth = transactions.get(month);
				if (transactionForCurrMonth != null && !transactionForCurrMonth.isEmpty()) {
					transactionForCurrMonth.stream().peek(t -> {
						Set<Long> accPair = new HashSet<>();
						accPair.add(t.getFromAccount());
						accPair.add(t.getToAccount());
						suspiciousAccounts.add(accPair);
					}).map(Transaction::getId).forEach(System.out::println);
				}
				System.out.println("");
			}

			System.out.println("Suspicious Accounts :");
			if (!suspiciousAccounts.isEmpty()) {
				suspiciousAccounts.stream().forEach(System.out::println);
			}

		}

	}

}
