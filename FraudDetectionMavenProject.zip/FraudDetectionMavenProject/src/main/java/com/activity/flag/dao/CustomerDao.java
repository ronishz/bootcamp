package com.activity.flag.dao;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import com.activity.flag.model.Customer;
import com.activity.flag.util.DataTransformer;
import com.activity.flag.util.FileReaderUtil;

public class CustomerDao {
	
	private List<Customer> customers;
	
	public List<Customer> getAllCustomers() {
		Stream<String> customerDataStream = null;
		try {
			customerDataStream = FileReaderUtil.readCustomerData();
		} catch (URISyntaxException | IOException e) {
			System.err.println("Error reading file: " + e);
		}
		
		List<Customer> customerData = DataTransformer.transformToCustomer(customerDataStream);
		setCustomers(customerData);
		return customerData;
	}
	
	public Customer getCustomerByAcccNumber(final Long accountNumber) {
		if (accountNumber == null) {
			return null;
		}
		
		if(customerDataEmpty()){
			getAllCustomers();
		}
		
		Optional<Customer> customerFromQuery = getCustomers().stream()
				.filter(c -> c.getAccountNumber() != null && c.getAccountNumber().equals(accountNumber)).findFirst();

		Customer customer = null;
		if (customerFromQuery.isPresent()) {
			customer = customerFromQuery.get();
		}
		return customer;
	}
	
	private boolean customerDataEmpty(){
		return getCustomers() == null || (getCustomers() != null && getCustomers().isEmpty());
	}

	public List<Customer> getCustomers() {
		return customers;
	}

	public void setCustomers(List<Customer> customers) {
		this.customers = customers;
	}

}
