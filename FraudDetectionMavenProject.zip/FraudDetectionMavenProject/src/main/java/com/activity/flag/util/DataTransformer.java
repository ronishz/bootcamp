package com.activity.flag.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.activity.flag.model.Customer;
import com.activity.flag.model.Transaction;

public class DataTransformer extends Constants {
	
	public static List<Customer> transformToCustomer(final Stream<String> lineStream) {
		List<Customer> customers = new ArrayList<>();
		if (lineStream != null) {
			return lineStream.filter(DataTransformer::lineNotBlank)
					.map(line -> line.trim().split(SEPERATOR_REGEX))
					.map(tokens -> new Customer(Long.valueOf(tokens[0]), tokens[1], tokens[2], Long.valueOf(tokens[3])))
					.collect(Collectors.toList());
		}
		return customers;
	}

	public static List<Transaction> transformToTransactions(final Stream<String> lineStream) {
		List<Transaction> transactions = new ArrayList<>();
		if (lineStream != null) {
			return lineStream.filter(DataTransformer::lineNotBlank)
					.map(line -> line.trim().split(SEPERATOR_REGEX))
					.map(tokens -> {
						Transaction transaction = null;
						transaction = new Transaction(tokens[0],
								LocalDate.parse(tokens[1], DateTimeFormatter.ofPattern(TRANSACTION_DATE_FORMAT)),
								Long.valueOf(tokens[2]), Long.valueOf(tokens[3]), Long.valueOf(tokens[4]));
						return transaction;
					}).collect(Collectors.toList());
		}
		return transactions;
	}

	public static boolean lineNotBlank(String line) {
		return line != null && !line.equals("");
	}
}
