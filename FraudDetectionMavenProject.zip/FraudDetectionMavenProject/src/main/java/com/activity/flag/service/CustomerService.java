package com.activity.flag.service;

import com.activity.flag.dao.CustomerDao;
import com.activity.flag.model.Customer;

public class CustomerService {
	
	private CustomerDao customerDao;
	
	public CustomerService() {
		this.customerDao = new CustomerDao();
	}

	public boolean equatePhoneNumber(final Customer customer1, final Customer customer2) {
		return customer1.getPhoneNumber() != null && customer1.getPhoneNumber().equals(customer2.getPhoneNumber());
	}

	public boolean equateAddress(final Customer customer1, final Customer customer2) {
		return customer1.getAddress() != null && customer1.getAddress().trim().equals(customer2.getAddress().trim());
	}

	public CustomerDao getCustomerDao() {
		return customerDao;
	}

	public void setCustomerDao(CustomerDao customerDao) {
		this.customerDao = customerDao;
	}
}
