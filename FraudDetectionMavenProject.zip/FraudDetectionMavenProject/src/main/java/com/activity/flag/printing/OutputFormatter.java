package com.activity.flag.printing;

import java.time.Month;
import java.util.List;
import java.util.Map;

import com.activity.flag.model.Transaction;

public interface OutputFormatter {

	public void print(Map<Month, List<Transaction>> transactions);

}
