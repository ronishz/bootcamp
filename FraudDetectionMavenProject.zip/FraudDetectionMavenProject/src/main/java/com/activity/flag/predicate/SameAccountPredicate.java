package com.activity.flag.predicate;

import com.activity.flag.dao.CustomerDao;
import com.activity.flag.model.Customer;
import com.activity.flag.model.Transaction;
import com.activity.flag.service.CustomerService;

public class SameAccountPredicate implements SuspiciousActivityPredicate {

	private CustomerDao customerDao;
	private CustomerService customerService;

	public SameAccountPredicate() {
		this.customerDao = new CustomerDao();
		this.customerService = new CustomerService();
	}

	@Override
	public boolean isTransactionSuspicious(Transaction transaction) {
		return transaction != null
				&& accountBelongsToSamePerson(transaction.getFromAccount(), transaction.getToAccount());
	}

	public boolean accountBelongsToSamePerson(final Long account1, final Long account2) {
		Customer customer1 = getCustomerDao().getCustomerByAcccNumber(account1);
		Customer customer2 = getCustomerDao().getCustomerByAcccNumber(account2);

		if (customer1 == null || customer2 == null) {
			return false;
		}
		return getCustomerService().equateAddress(customer1, customer2)
				&& getCustomerService().equatePhoneNumber(customer1, customer2);
	}

	public CustomerDao getCustomerDao() {
		return customerDao;
	}

	public void setCustomerDao(CustomerDao customerDao) {
		this.customerDao = customerDao;
	}

	public CustomerService getCustomerService() {
		return customerService;
	}

	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}

}
