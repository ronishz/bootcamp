package com.activity.flag.service;

import java.time.Month;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.activity.flag.dao.TransactionDao;
import com.activity.flag.model.Transaction;
import com.activity.flag.predicate.SuspiciousActivityPredicate;
import com.activity.flag.printing.OutputFormatter;

public class TransactionService {

	private TransactionDao transactionDetailsDao;
	private OutputFormatter outputFormatter;
	private CustomerService customerService;
	private SuspiciousActivityPredicate predicate;

	public TransactionService() {
		this.transactionDetailsDao = new TransactionDao();
		this.customerService = new CustomerService();
	}
	
	public void analyzeAndGenerateReport() {
		List<Transaction> transactions = getTransactionDetailsDao().getAllTransactions();
		Map<Month,List<Transaction>> suspiciousTransactionsByMonth = new LinkedHashMap<>();
		if(transactions != null && !transactions.isEmpty()){
			transactions.stream()
			.filter(getPredicate()::isTransactionSuspicious)
			.forEach(t -> separateTransactionByMonth(t, suspiciousTransactionsByMonth));
			
			//print report
			getOutputFormatter().print(suspiciousTransactionsByMonth);
		}
	}
	
	public void separateTransactionByMonth(final Transaction t, final Map<Month,List<Transaction>> suspiciousTransactionsByMonth){
		Month transactionMonth = t.getTransactionDate().getMonth();
		if(!suspiciousTransactionsByMonth.containsKey(transactionMonth)){
			suspiciousTransactionsByMonth.put(transactionMonth, new ArrayList<>());
		}
		suspiciousTransactionsByMonth.get(transactionMonth).add(t);
	}

	public TransactionDao getTransactionDetailsDao() {
		return transactionDetailsDao;
	}

	public void setTransactionDetailsDao(TransactionDao transactionDetailsDao) {
		this.transactionDetailsDao = transactionDetailsDao;
	}

	public OutputFormatter getOutputFormatter() {
		return outputFormatter;
	}

	public void setOutputFormatter(OutputFormatter outputFormatter) {
		this.outputFormatter = outputFormatter;
	}

	public CustomerService getCustomerService() {
		return customerService;
	}

	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}

	public SuspiciousActivityPredicate getPredicate() {
		return predicate;
	}

	public void setPredicate(SuspiciousActivityPredicate predicate) {
		this.predicate = predicate;
	}
}
